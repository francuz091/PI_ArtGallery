﻿namespace ArtGallery.API.Data
{
    public class ArtGalleryContext
    {
    }
}
