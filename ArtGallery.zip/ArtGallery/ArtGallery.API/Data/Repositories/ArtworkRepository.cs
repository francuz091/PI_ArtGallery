﻿namespace ArtGallery.API.Data.Repositories
{
    public class ArtworkRepository
    {
    }
}
