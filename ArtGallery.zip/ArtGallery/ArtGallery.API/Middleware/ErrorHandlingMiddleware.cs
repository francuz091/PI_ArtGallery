﻿namespace ArtGallery.API.Middleware
{
    public class ErrorHandlingMiddleware
    {
    }
}
