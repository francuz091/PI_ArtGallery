﻿namespace ArtGallery.API.Middleware
{
    public class RequestLoggingMiddleware
    {
    }
}
