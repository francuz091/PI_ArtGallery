﻿namespace ArtGallery.API.Models.DTO
{
    public class ArtworkDTO
    {
    }
}
