﻿namespace ArtGallery.API.Models.Domain
{
    public class RoleType
    {
    }
}
