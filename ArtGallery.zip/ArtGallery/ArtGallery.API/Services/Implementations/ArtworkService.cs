﻿namespace ArtGallery.API.Services.Implementations
{
    public class ArtworkService
    {
    }
}
