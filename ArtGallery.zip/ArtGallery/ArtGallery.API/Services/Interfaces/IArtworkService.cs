﻿namespace ArtGallery.API.Services.Interfaces
{
    public class IArtworkService
    {
    }
}
